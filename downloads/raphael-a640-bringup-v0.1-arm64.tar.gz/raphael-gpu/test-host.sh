#!/bin/bash
set -euo pipefail
HERE=$(cd "$(dirname "$0")" && pwd)
mkdir -p "$HERE/build"
${CC:-gcc} -std=c11 -O1 -g -Wall -Wextra -Werror -fsanitize=address,undefined \
 -I "$HERE/src/xnu/files/bsd/dev" "$HERE/tests/a640_test.c" -o "$HERE/build/a640_test"
ASAN_OPTIONS=detect_leaks=0 "$HERE/build/a640_test" "$@"
