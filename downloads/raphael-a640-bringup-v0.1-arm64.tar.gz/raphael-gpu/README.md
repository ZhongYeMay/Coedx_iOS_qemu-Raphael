# Redmi K20 Pro / Adreno 640 GPU bring-up v0.1

已写入 XNU 并在云端编译的分阶段驱动，不是已经可用的 GPU 加速驱动。没有在 SM8150 真机上运行，不能据此宣称 Metal、OpenGL ES 或桌面合成已经硬件加速。当前调用链不会注册 RedwoodGPU 加速服务。

## 这版实现了什么

- 新增 `raphael_adreno.c`，只从 `raphael=1` 分支调用，不复用 redwood/SC7280 的寄存器地址。
- SM8150 的 GPU/GMU/GPUCC/SMMU 分别位于 `0x02c00000 / 0x02c6a000 / 0x02c90000 / 0x02ca0000`，GCC 为 `0x00100000`。
- A640 GMU 固件分段解析、范围和重叠检查、加载计划；区分片内 TCM 寄存器与外部 GPU IOVA，绝不把固件中的 IOVA 当作 CPU 物理地址。
- A640 DTCM 基址使用 `0x40000`，不是现有 A650 家族路径的 `0x10004000`。目标 DT 身份为 `0x06040001`，不是硬件实测识别值。
- 供后续 SMMU 实现接入的固件复制接口；先验证全部固件，缺少外部地址空间后端时，在第一次写入之前拒绝加载。当前 XNU 入口只输出加载计划，不调用复制接口。
- 读取 GPUCC；在 CX 已通电、GMU 时钟来源与分频满足要求时，临时投票相关 GCC/GPUCC 时钟，设置超时，失败及完成时逆序恢复自己更改的控制位；保留其他投票和硬件状态位。
- 读取 GMU 启动状态、计数器和 SMMU ID；仅在 GMU 已保持复位时，选择性测试一个 ITCM 字并恢复原值，不主动复位运行中的 GMU。

没有实现冷启动的 RPMh 电压/互连投票，也没有依赖猜测直接强开 CX/GX。因此若固件没有留下已供电的 CX 或符合要求的时钟源，第3阶段会停止。这是下一步需解决的实际硬件前提。

## 文件

- `src/xnu/files/bsd/dev/raphael_adreno.c`：XNU 入口及硬件诊断。
- `src/xnu/files/bsd/dev/raphael_a640.h`：共享固件解析、复制接口、时钟操作与恢复代码。
- `raphael-a640-on-v2.patch`：叠加到此前 raphael-drivers-v2 的补丁，已用 v2 源文件执行 apply 检查。
- `build/raphael_adreno-arm64.o`：已编译 Mach-O ARM64 内核对象，不能作为独立 kext 加载。
- `build/mach.raphael-a640-bringup.arm64`：已链接实验内核，包含之前的 UFS/触摸实验代码；不是 boot.img，也未打包手机 loader。
- `build/kernel-build.log`、`build/host-tests.log`、`build/qemu-smoke.log`：实际验证日志。
- `ARTIFACTS.json`：构建产物、源码和测试记录摘要。

## 验证结果

1. GCC + ASan/UBSan 主机模型测试通过：固件截断/越界/重叠、错误地址空间、预检查、复制回调失败、时钟超时/拒绝写入、恢复顺序、保留其他及继承投票。
2. 用 linux-firmware 公开的 `a640_gmu.bin` 实测解析：37680 字节，7段，TCM 21856字节，外部15712字节。复制目的地使用模型内存，未在硬件执行。对全部截断长度及10000次确定性字节变异运行解析检查。
3. 新 C 文件交叉编译完成并链接进 ARM64 内核，无未解析符号。
4. 整体 make 退出码为2：既有 IOKit/Libkern/Private DriverKit 导出及 symbolset 检查仍失败，不能表述为整个构建全通过。相关错误在完整构建日志中。
5. QEMU 使用新内核和小型 APFS 固件镜像执行 `raphael=1 raphael_gpu=5`：固件检查成功，随后因 loader SoC base 为 `0x8000000` 拒绝手机 MMIO；继续进入静态用户态 hello（PID1，UID0）。测试 hello 主动退出后出现预期的 PID1 panic；这不是 GPU MMIO 崩溃。日志末尾会重放之前的日志，不要把重放当作第二次启动。

第2–5阶段的手机硬件路径只通过模型及编译验证，尚无真机结果。QEMU 不模拟 Adreno 640，不能验证这些硬件步骤。

## 接入及参数

已有 v2 树中先执行：

```sh
git apply --check /path/to/raphael-gpu/raphael-a640-on-v2.patch
git apply /path/to/raphael-gpu/raphael-a640-on-v2.patch
```

`xnu/apply.sh` 仅处理新建的 XNU 源码树。如果重用已生成树，需要同步本包两个新增 C/header、`redwood_input.c`、`redwood_input.h`，并把 `bsd/dev/raphael_adreno.c standard` 加入该树的 `bsd/conf/files`。云端已完成同步并实际链接。

不设置 `raphael_gpu` 时不启用驱动。`gpu=1` 不能启用本驱动。

| 参数 | 行为 |
|---|---|
| `raphael=1 raphael_gpu=1` | 仅解析镜像中固件，无硬件 MMIO |
| `raphael=1 raphael_gpu=2` | 加上 GPUCC 只读快照 |
| `raphael=1 raphael_gpu=3` | 加上有条件的临时时钟投票和恢复 |
| `raphael=1 raphael_gpu=4` | 加上 GMU/SMMU 快照及计数器检查 |
| `raphael=1 raphael_gpu=5` | 加上已复位 GMU 的 ITCM 单字往返测试 |

固件需要镜像中 `fw/a640_gmu.bin`、`fw/a630_sqe.fw`。现有用户态构建器从 `fw-gpu/` 收集这些文件。应先与手机 Android 的实际固件及 GPU 版本核对；本次公开固件的测试不证明任意厂商版本兼容。解析器只接受已经核对的 A640 分段头，不支持任意后续 GPU 固件格式。

`bash test-host.sh [a640_gmu.bin路径]` 复现主机测试。包不包含 Qualcomm 固件或 Apple 系统镜像。`build/run-qemu-smoke.sh` 是本云工作区的验证脚本，引用工作区路径及未包含的测试 APFS。

## 到硬件加速还差什么

冷启动 RPMh/CX 电源和总线投票 → 配置并验证 GMU 专属 SMMU 上下文 → 放置外部固件/日志/HFI 队列 → A640 的 PDC/RSC 与 HFI 启动 → GX 供电及 zap shader 的安全加载 → CP/SQE、命令环和 fence 完成验证 → 对接 RedwoodGPU 的提交/缓冲接口和用户态图形后端。各阶段都要有真机日志才能判定通过，不能以文件成功编译代替。
