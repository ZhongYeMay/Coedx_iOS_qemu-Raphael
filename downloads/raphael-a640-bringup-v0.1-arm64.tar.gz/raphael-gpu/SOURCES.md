# 核对来源

基线：oosexgang/hackios-xnu-kernel d82c64a3a31cd27a0a0afbf6e213e467e44b1b4c，加本工作区已有 raphael-drivers-v2。

Linux v6.12（本次下载并核对）：
- https://github.com/torvalds/linux/blob/v6.12/arch/arm64/boot/dts/qcom/sm8150.dtsi
- https://github.com/torvalds/linux/blob/v6.12/drivers/clk/qcom/gpucc-sm8150.c
- https://github.com/torvalds/linux/blob/v6.12/drivers/clk/qcom/gcc-sm8150.c
- https://github.com/torvalds/linux/blob/v6.12/drivers/gpu/drm/msm/adreno/a6xx_gmu.c
- https://github.com/torvalds/linux/blob/v6.12/drivers/gpu/drm/msm/adreno/a6xx_catalog.c
- https://github.com/torvalds/linux/blob/v6.12/drivers/gpu/drm/msm/registers/adreno/a6xx_gmu.xml

测试固件：下载时的 linux-firmware main，哈希锁定在 ARTIFACTS.json，不在发布包内。
- https://kernel.googlesource.com/pub/scm/linux/kernel/git/firmware/linux-firmware/+/refs/heads/main/qcom/a640_gmu.bin
- https://kernel.googlesource.com/pub/scm/linux/kernel/git/firmware/linux-firmware/+/refs/heads/main/qcom/a630_sqe.fw

新代码依据寄存器事实和固件格式独立实现，不将 Linux API 当成 XNU API，也不把 Linux 驱动成功视作 iOS 加速成功。
