# QEMU VirtIO-GPU 2D for HackiOS / XNU

这是一份已接入 XNU framebuffer 的 QEMU 专用 VirtIO-GPU 2D 显示驱动，不是 Adreno 驱动，也不是 Metal、OpenGL 或 virgl 3D 加速实现。

## 结论与边界

先用前一版 A640 内核启动了完整 iOS。日志明确显示 `no accelerated renderer; the software one will draw`。QEMU 没有 Adreno 640 设备模型，不能用 A640 寄存器驱动它。

本次新实现的 VirtIO-GPU 驱动成功和 QEMU 的 `virtio-gpu-device` 协商、创建1125×2048显示资源，注册9216000字节的 framebuffer 后备内存，执行 `TRANSFER_TO_HOST_2D`、`RESOURCE_FLUSH`、`SET_SCANOUT`，校验设备返回的 fence 和响应。界面截图通过 QMP 指定 `device=vgpu,head=0`，来自虚拟 GPU 的输出，而不是只截原有 ramfb。

当前 CoreAnimation 仍在 CPU 上渲染。该驱动使 QEMU 虚拟显卡可用，没有证明界面帧率提升。主机没有暴露 `/dev/dri`；安装的 QEMU 也未提供 `virtio-gpu-gl-device`。这些观测记录在 `build/host-capabilities.txt` 与 `build/virgl-probe.txt` 中。需要3D加速时，还需具有可用GPU/EGL上下文的宿主、virgl/rutabaga 后端，以及 XNU 用户态相应的上下文/资源/命令提交和图形API实现；只添加显卡设备或使显示资源成功创建都不够。

## 实现

- `redwood_virtio_gpu.c`：QEMU virt 的32个 virtio-mmio 插槽中识别GPU设备16；只接受现代 VERSION_1，显式不协商 VIRGL/3D、blob、packed ring 等功能。
- 独立控制队列、物理页描述符、内存屏障、500ms请求超时、used-ring及响应类型/长度/fence校验。出现故障重置设备，保留原boot framebuffer。
- 请求、响应及队列内存保持 wired。超时后不释放或重复使用可能仍在DMA中的内存；重置本身也有超时。
- 将 boot framebuffer 的真实物理页注册为 scatter/gather 后备内存；不假定物理连续，支持页内起始偏移及连续区间合并。真实运行时合并为一个物理区间。
- 直接共享已存在的像素缓冲区，guest 中不再复制一份整屏图像；主机仍需按VirtIO 2D协议传输图像。
- `MiniIOMobileFramebuffer.cpp` 在每次完成绘制后提交传输和刷新；不伪造任何可用的3D加速器标记。
- 只有 `virtio_gpu=1` 且 loader 的 SoC base 为 QEMU virt 的 `0x08000000` 时才访问虚拟设备。手机地址不适用。

当前限制：固定一个扫描输出/显示资源、固定packed 32位BGRX格式；没有热插拔、动态改分辨率、硬件光标、3D上下文、着色器、GPU合成或Metal实现。资源与队列内存在本次内核生命周期保留，未实现动态卸载。ramfb 保留作启动及故障回退显示；故障后并不会自动切换QEMU窗口所选控制台，需要在宿主选择ramfb控制台查看。

## 使用

包含此前 A640 驱动的源码树中应用：

```sh
git apply --check qemu-virtio-gpu-on-a640.patch
git apply qemu-virtio-gpu-on-a640.patch
```

新建 XNU 树可走 `xnu/apply.sh`。已有生成树需同步两个新增 driver/header、`MiniIOMobileFramebuffer.cpp`，并在 `bsd/conf/files` 添加 `bsd/dev/redwood_virtio_gpu.c standard`；本云工作区已经同步并实际链接。

启动参数及设备：

```text
virtio_gpu=1 virtio_input=1
-global virtio-mmio.force-legacy=false
-device virtio-gpu-device,id=vgpu,xres=1125,yres=2048
```

继续保留 `-device ramfb` 给UEFI loader使用。不要给这个纯QEMU运行添加 `raphael=1`，因为现有raphael分支会跳过虚拟触摸输入。`run-ios.sh` 是本云工作区的启动脚本，依赖现有工具链及iOS镜像路径；包里没有系统镜像。

`python3 screenshot.py 输出.png` 直接截取VirtIO-GPU；本脚本依赖工作区现有 `qemu/touch.py` QMP helper。QMP端口同一时刻只允许一个客户端，连续录制时需要在同一连接调度输入，或使用不同的显示/输入通道。

## 验证

- `bash test-host.sh`：GCC + ASan/UBSan 检查结构体线格式大小、packed几何、非连续物理页与合并、非对齐起点、范围/容量边界、缺失物理映射、返回长度、错误描述符与fence。
- 新驱动和 framebuffer 改动已交叉编译、链接成ARM64 Mach-O内核，无未解析符号。
- 整体make仍返回2，原因是已有DriverKit导出和symbolset检查错误；不能把整体构建写成全通过。源码编译和内核链接完成，详见完整日志。
- QEMU 10.0.13 / ARM64 TCG、2vCPU、7GB RAM，使用新内核与已有iOS16.5镜像实际运行；已进入完整桌面并通过触摸打开设置→通用→关于本机，虚拟设备至少确认完成240帧、fence488；没有观察到虚拟GPU超时或错误完成响应。`build/virtio-desktop.png`、`build/virtio-settings.png`、`build/virtio-about.png` 均直接截取设备 `vgpu`。详见日志、截图和 `ARTIFACTS.json`。

## 参考

VirtIO 1.2 GPU规范：
https://docs.oasis-open.org/virtio/virtio/v1.2/virtio-v1.2.html

QEMU VirtIO GPU的2D/3D后端区别：
https://www.qemu.org/docs/master/system/devices/virtio-gpu.html

基线：oosexgang/hackios-xnu-kernel d82c64a3a31cd27a0a0afbf6e213e467e44b1b4c，加此前raphael-drivers-v2和raphael-a640-bringup-v0.1。
