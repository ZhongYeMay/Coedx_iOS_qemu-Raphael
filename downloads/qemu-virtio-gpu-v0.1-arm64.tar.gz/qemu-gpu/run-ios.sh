#!/bin/bash
set -euo pipefail
source /workspace/toolchain/env.sh
export TMPDIR=/workspace/qemu-test/tmp
export QEMU_EFI=/workspace/toolchain/root/usr/share/AAVMF/AAVMF_CODE.fd
export QEMU_VARS=/workspace/toolchain/root/usr/share/AAVMF/AAVMF_VARS.fd
export QEMU_MODULE_DIR=/workspace/toolchain/root/usr/lib/x86_64-linux-gnu/qemu
export QEMU_SMP=2
export CMDLINE="cpus=2 virtio_gpu=1 ${CMDLINE:-}"
mkdir -p "$TMPDIR"
cd /workspace/hackios
exec bash qemu/run-ios.sh "${1:-900}" -nic none -L /workspace/toolchain/root/usr/share/qemu \
 -device virtio-gpu-device,id=vgpu,xres=1125,yres=2048
