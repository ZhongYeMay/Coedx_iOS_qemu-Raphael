#!/usr/bin/env python3
"""Capture the VirtIO GPU console, not the boot ramfb. Requires the workspace QMP helper."""
import sys
from pathlib import Path
sys.path.insert(0,'/workspace/hackios/qemu')
from touch import Qmp
out=str(Path(sys.argv[1]).resolve())
Qmp().command('screendump',filename=out,device='vgpu',head=0,format='png')
print(out)
