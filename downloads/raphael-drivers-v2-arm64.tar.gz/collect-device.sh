#!/bin/sh
# Read-only Android collection. Writes only the selected directory on the computer.
set -eu
out=${1:-raphael-device-info}
command -v adb >/dev/null 2>&1 || { echo 'adb is required' >&2; exit 1; }
mkdir -p "$out"
adb get-state > "$out/adb-state.txt"
adb shell 'getprop ro.product.device; getprop ro.product.model; getprop ro.boot.hardware; uname -a' > "$out/model.txt"
adb shell 'ls -l /dev/block/by-name; cat /proc/partitions' > "$out/partitions.txt"
# Root may be required. Failure does not trigger permission changes or reboot.
if adb exec-out 'su -c "cat /sys/firmware/fdt"' > "$out/device.dtb.tmp" 2> "$out/fdt-error.txt"; then
    python3 - "$out/device.dtb.tmp" "$out/device.dtb" <<'PY'
from pathlib import Path
import sys
p=Path(sys.argv[1]); data=p.read_bytes()
if data[:4] != bytes.fromhex('d00dfeed'):
    raise SystemExit('No valid FDT obtained; root or a different device-tree extraction method is required')
p.rename(sys.argv[2])
PY
else
    rm -f "$out/device.dtb.tmp"
    echo 'FDT read failed; other read-only information was retained' >&2
fi
echo "Saved to $out; no partitions written, no reboot requested."
