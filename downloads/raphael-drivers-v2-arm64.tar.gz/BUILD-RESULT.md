# v2 云编译验证（2026-10-23 UTC）

## 编译产物

位于 `build/`：

- `loader-raphael.efi`：以 `-DRAPHAEL_BUILD` 编译的 ARM64 PE32+ UEFI application。
- `mach.raphael-experimental.arm64`：包含 GT9886、GPIO I2C、raphael 初始化分支和 UFS 只读策略的 ARM64 Mach-O 内核。
- `mach.raphael-experimental.arm64.unstripped`：保留符号版本。
- `raphael_touch-arm64.o`：静态链接进内核的触摸目标文件，不是可动态安装的驱动。

编译器和依赖沿用 v1：Clang/lld 19、Theos ld64-609、iPhoneOS16.5 SDK。
完整源码基线仍为 `d82c64a3a31cd27a0a0afbf6e213e467e44b1b4c`。

## 已验证

- 主机协议测试通过，ASan/UBSan 未报告越界或未定义行为；LeakSanitizer 因云执行器 ptrace 限制关闭。
- 测试覆盖 GT9886 坏校验、短包、无关事件、重复/越界触点 ID、10 点帧、空帧释放、坐标范围。
- I2C 模型测试覆盖寄存器高字节先发、0x5d 地址、重复 START、读数据、最终 NACK、地址拒绝和时钟拉伸超时。
- 新驱动通过实际 XNU 头文件的 ARM64 编译，并完成整个内核链接。
- `nm -u` 的结果为空；符号表包含 `_raphael_touch_init`、`_raphael_touch_quiesce`、`_redwood_ufs_init`。
- v2 补丁对实际修改树反向应用检查通过；更新后的上游 XNU 基础补丁也通过反向检查。

## 未通过的构建检查

最终 make 退出码为 2，发生在内核生成后的 `check_all_exports` 与 Libkern/IOKit/Private symbolset 检查，符合上游说明的 DriverKit 桩导出问题。
不能视为全部构建检查通过；见 `build/kernel-build-final.log`。内核文件已实际生成和检查。

专用 loader 有一个 `ramfb_phone_screen` 未使用警告：raphael 模式刻意不走 QEMU ramfb 路径。
没有用空函数替代硬件实现来让链接通过。

## 必须区分的验证范围

这些结果证明源码可编译、协议逻辑通过模型测试，以及 ARM64 链接完整。
它们不能证明 MMIO 可访问、GPIO 电压/时序正确、GT9886 真机可识别或 UFS 系统能启动。
目前没有连接用户设备，也没有制作匹配该机 UEFI 的 boot.img。

本轮实现的是 GT9886 输入路径、SM8150 平台描述/GOP 接入和 UFS 路径限制。
未适配 GPU、Wi-Fi、音频、PMIC 按键、蜂窝、充电或 DSI 休眠管理；raphael 初始化会跳过 redwood 的对应模块。
