# raphael 驱动适配 v2（实验性，尚未真机验证）

基线：`oosexgang/hackios-xnu-kernel` 的 `d82c64a3a31cd27a0a0afbf6e213e467e44b1b4c`。
本包是在 v1 UFS 只读补丁之上继续开发，但补丁本身包含 v1，适用于上述干净基线；不要重复叠加。

## 本次新增

### GT9886 触摸驱动

`raphael_touch.c` 是独立的实验性 XNU 驱动，接入现有 `/dev/redwood-touch`，不是 Linux `.ko`。

- 使用 SM8150 SOUTH TLMM 基址 `0x03d00000`，而不是 redwood 的 GPIO 地址。
- SDA GPIO57、SCL GPIO58、IRQ GPIO122、reset GPIO54、AVDD GPIO98、VDDIO GPIO100。
- 开漏 GPIO 模拟 I2C；不会在 SDA/SCL 上主动输出高电平；带 ACK/NACK、重复 START、STOP 和时钟拉伸超时。
- I2C 地址 `0x5d`，从 `0x4535` 读取并核对 `9886` 产品 ID。
- 读取 `0x4100` Normandy 报告，校验非空数据包，支持 10 个触点和抬手，坐标缩放到输入接口的 0..65535。
- 默认 8ms 轮询；初始化失败恢复 GPIO；返回 loader 时尽力停止轮询、恢复 GPIO。
- 必须同时设置 `raphael=1 raphael_touch=1` 才访问硬件。`raphael_touch_reset=1` 可选择初始化时拉低复位。

局限：依赖板载 I2C 上拉及已有控制器固件；没有固件上传、配置请求处理、硬件 IRQ、休眠唤醒或生产级错误恢复。
模拟总线的实际速度受 CPU 调度影响；主机模型测试不代表真实电气时序已验证。
返回时若其他 CPU 已停且总线锁未释放，会记录日志并跳过引脚恢复，以免和残留传输竞争。

### SM8150 loader 平台与 framebuffer 接入

编译 `loader.c` 时加入 `-DRAPHAEL_BUILD`，使用新增的 raphael 平台：

- GICD `0x17a00000`、GICR `0x17a60000`；8 核，MPIDR 第二 affinity 字段，PSCI SMC。
- 小核掩码 `0x0f`。
- 使用 UEFI 已初始化的 GOP framebuffer，没有新增完整 DSI 驱动。
- 参考 DTS 中 framebuffer 为 `0x9c000000`、1080×2340。专用 loader 会拒绝不匹配的 GOP，避免误选 QEMU。
- 若真实 GOP 地址不同，必须先核实，再通过 `-DRAPHAEL_FB_BASE=实际地址` 重编；不要猜地址。
- 不允许强制 RAM 窗口覆盖 UEFI 内存图。
- 为 UFS mailbox 保留 firmware 所在 CPU；默认将 XNU 移到另一核。
- 专用 loader 禁止将日志写入 redwood 的 logdump，也不启用该机型的充电器/相机/闪光灯服务。

这只是平台描述和 GOP 接入，不是可独立启动的 raphael UEFI。payload 和 PE 加载地址仍需与实际 UEFI 内存图匹配。

### 隔离其他机型的驱动

内核收到 `raphael=1` 时，在输入初始化入口只调用 raphael 触摸和 UFS；跳过 redwood 的触摸、按键、调频、GPU、Wi-Fi、音频等初始化。
它们没有被适配，不能因为同为 Qualcomm 就启用。
UFS 写入和原生控制器接管在 `raphael=1` 下同样被禁止，即使没有显式的 `raphael_ufs=1`。

## 文件与使用

- `raphael-drivers-v2.patch`：对固定 HackiOS 基线的完整源码补丁（含 v1）。
- `src/`：修改后的源码和新增文件。
- `build/`：ARM64 编译产物、日志、主机测试及校验信息；最终结果见 `BUILD-RESULT.md`。
- `tests/`、`build-checks.sh`：可独立重跑的协议测试，使用 ASan/UBSan（关闭受 ptrace 限制的泄漏检查）。
- `reference-manifest.json`、`SOURCES.md`：公开参考资料及内容校验。
- `collect-device.sh`：在有 adb 的电脑上只读收集 Android 型号、分区列表和可读取的运行时 DTB；不会刷写或重启。

在干净的固定基线中：

```sh
git apply --check /path/to/raphael-drivers-v2.patch
git apply /path/to/raphael-drivers-v2.patch
```

然后按上游工作流准备 XNU 源码。`cloud-build-paths.patch` 记录本云环境路径；`cloud-awk-generator.patch` 修复生成脚本，应用于生成后的 XNU 源码树。
本包不包含 iOS 文件，也未构建 iOS 系统镜像。

## 当前不提供可刷写 boot.img

本次没有连接你的真机，未获得实际 DTB、GPT、xbl 或 UEFI 日志。
没有完成 raphael 的 UEFI 启动链、内存保留区和 USB 固件兼容性验证；内核构建配置仍沿用上游 BCM2837 基础。
ARM64 `.efi`、内核及 `.o` 均是供进一步集成的开发产物，不能直接当作 K20 Pro ROM 刷入。

下一步最需要的是：raphael UEFI 能运行 loader 并提供准确 GOP/内存图，以及 UFS 只读枚举日志。
有这些证据后，才能验证本次驱动的真实寄存器访问、触摸识别和 APFS 系统卷挂载。
