#!/bin/sh
# Run with a complete patched HackiOS tree and clang/lld-link on PATH.
set -eu
tree=${1:?usage: sh build-loader.sh /path/to/patched/hackios}
out=$(CDPATH= cd -- "$(dirname "$0")" && pwd)/build
mkdir -p "$out"
clang --target=aarch64-unknown-windows -DRAPHAEL_BUILD \
    -ffreestanding -fno-builtin -fno-stack-protector -fshort-wchar \
    -mgeneral-regs-only -O1 -Wall -Wextra -Wno-unused-parameter \
    -c "$tree/xnuloader/loader.c" -o "$out/loader-raphael.obj"
# Preferred PE address is inherited from upstream, not a verified raphael RAM reservation.
lld-link /subsystem:efi_application /entry:efi_main /nodefaultlib /base:0xA1000000 \
    "/out:$out/loader-raphael.efi" "$out/loader-raphael.obj"
