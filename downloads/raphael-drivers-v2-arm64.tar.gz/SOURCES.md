# 参考资料

这些文件用于确认板级接线、寄存器布局和线上协议；本包不包含 Linux 驱动代码。
源码为独立实现，参考文件本身的许可证不随本包重新授权。

- [SM8150 SoC DTSI](https://github.com/Aospa-raphael-unofficial/linux/blob/sm8150-xiaomi-raphael/arch/arm64/boot/dts/qcom/sm8150.dtsi)：GIC、PSCI、CPU MPIDR、命名 TLMM 分区。
- [raphael DTS](https://github.com/Aospa-raphael-unofficial/linux/blob/sm8150-xiaomi-raphael/arch/arm64/boot/dts/qcom/sm8150-xiaomi-raphael.dts)：触摸供电、IRQ/reset、I2C 地址、屏幕分辨率与参考 framebuffer。
- [SM8150 pinctrl](https://github.com/Aospa-raphael-unofficial/linux/blob/sm8150-xiaomi-raphael/drivers/pinctrl/qcom/pinctrl-sm8150.c)：GPIO54/57/58/98/100/122 均在 SOUTH，寄存器步长0x1000，OE bit9、input bit0、output bit1。
- [Goodix GTX8 header](https://github.com/Aospa-raphael-unofficial/linux/blob/sm8150-xiaomi-raphael/drivers/input/touchscreen/goodix_gtx8.h)：Normandy 格式、寄存器和 ID。
- [Goodix GTX8 driver](https://github.com/Aospa-raphael-unofficial/linux/blob/sm8150-xiaomi-raphael/drivers/input/touchscreen/goodix_gtx8.c)：GT9886 产品号、非空报告的8位求和校验、空帧释放语义、状态清除和供电等待时间。
- [HackiOS porting](https://github.com/oosexgang/hackios-xnu-kernel/blob/d82c64a3a31cd27a0a0afbf6e213e467e44b1b4c/docs/PORTING.md)：UEFI framebuffer、平台字段与输入接口。

读取时的 Linux Git tree SHA 与文件 SHA256 记录在 `reference-manifest.json`；这只是公开参考板配置，不是从用户这台手机提取的 DTB。
