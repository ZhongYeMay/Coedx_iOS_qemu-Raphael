#!/bin/sh
set -eu
cd "$(dirname "$0")"
mkdir -p build
headers=src/xnu/files/bsd/dev
for test in touch i2c; do
    gcc -std=c11 -Wall -Wextra -Werror -fsanitize=address,undefined -I"$headers" "tests/${test}_test.c" -o "build/${test}-test"
    # LeakSanitizer cannot run under this cloud executor's ptrace supervision.
    ASAN_OPTIONS=detect_leaks=0 "./build/${test}-test"
done
