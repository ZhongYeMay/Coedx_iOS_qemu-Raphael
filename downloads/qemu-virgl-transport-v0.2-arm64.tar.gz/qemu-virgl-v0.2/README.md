# QEMU virgl transport v0.2（实验构建）

此包在原VirtIO-GPU v0.1之上增加显式启用的virgl v1链路：capset、上下文、3D资源、清屏提交、fence、像素读回与清理。

实际验证：QEMU10.0.13 + virglrenderer1.1.0 + llvmpipe，64×64红/绿两轮读回，每轮4096像素零差异；完整iOS继续进入桌面与设置；缺少VIRGL的2D设备正确回退。没有实现应用OpenGL/Metal或桌面硬件加速，也没有验证顶点/片元着色器。

`patches/on-v0.1.patch`用于已有v0.1的HackiOS源码树。若已有生成的XNU树，还需同步两个driver/header到该树的bsd/dev目录后编译。本包内核已编译链接，无未解析符号；整体make仍有既有DriverKit导出/symbolset检查失败（退出码2），详见日志。内核不是boot.img。

运行配置、软件EGL测试适配器及截图限制见experimental/virgl/README.md。该适配器通过显式进程级LD_PRELOAD使用EGL surfaceless并强制llvmpipe/softpipe，不修改系统库或QEMU二进制。普通2D配置仍是默认；具体测试启动脚本见已发布项目分支。

GL扫描输出的QMP截图返回no surface。本包docs/images中的本轮系统图片明确来自ramfb镜像，不当作GL输出。独立3D执行证据来自像素读回与fence。完整iOS使用初版软件EGL适配器；错误处理加固版另通过原生错误路径、EGL初始化及最小XNU virgl读回测试。

最小测试的hello作为PID1主动退出后会产生预期panic；完整iOS会话没有观察到内核panic。日志可能重放历史内容，不要按重放重复计数。

仓库：https://github.com/ZhongYeMay/Coedx_iOS_qemu-Raphael
包内不含iOS镜像、SDK、Qualcomm固件或第三方共享库。
